drop type if exists numero_operaciones_producto_servicio_por_moneda_instmonetario cascade;
create type numero_operaciones_producto_servicio_por_moneda_instmonetario as (
	anio 							    integer,
	clave_formulario 					text,
	clave_entidad 						text,
	producto_servicio 					integer,
	tipo_moneda 						integer,
	tipo_instrumento_monetario 			integer,
	operac_entr_salida					integer,
	numero_operaciones                  integer,  
	monto_operaciones					integer
);

create or replace function numero_operaciones_producto_servicio (integer,integer)
	returns setof numero_operaciones_producto_servicio_por_moneda_instmonetario as $$
	declare
	r 			numero_operaciones_producto_servicio_por_moneda_instmonetario%rowtype;
	clave_ent 	alias for $1;
	perio 		alias for $2;
	p_inicial 	integer;
	p_final 	integer;
	r_prod 		record;
	r_paso		record;
	rec 		record;
	r_paso_pro	record;
	y 			integer;
	fecha 		varchar;

	begin

	p_inicial 	:=(perio||'01')::integer;
	p_final 	:=(perio||'12')::integer;

	DROP table IF EXISTS copiar;
	CREATE temp table copiar(
		id    integer,
		fila  text);
	y:=0;
	insert into copiar values(y,'anio;clave_formulario;clave_entidad;producto_servicio;tipo_moneda;tipo_instrumento_monetario;operac_entr_salida;numero_operaciones;monto_operaciones');
	y:=1;

	drop table if exists temp_productos;
	create temp table temp_productos (idcuestionario integer, idproducto integer);
		FOR rec in  select * from tablas
					where idtabla = 'cuestionario_opera_cnbv2023'
					order by idelemento::integer
	loop
		FOR r_paso_pro in (select idprodu FROM regexp_split_to_table((trim(rec.dato2)),',') as idprodu) 
		loop
			if(r_paso_pro.idprodu <> '') then
				insert into temp_productos values(rec.idelemento::integer, r_paso_pro.idprodu::integer);
			end if;
		end loop;
	end loop;

	drop table if exists temp_auxi;
	create temp table temp_auxi as 
		(select ad.*, te.idcuestionario
		 from auxiliares_d ad 
		 inner join temp_productos te using (idproducto)
		 where ad.tipomov = 0 and ad.idtipo in (1,2) and ad.periodo:: integer between p_inicial and p_final
		 UNION ALL 
		 select ad.*, te.idcuestionario
		 from auxiliares_d_h ad 
		 inner join temp_productos te using (idproducto)
		 where ad.tipomov = 0 and ad.idtipo in (1,2) and ad.periodo:: integer between p_inicial and p_final
		 UNION ALL
		 select ad.*, te.idcuestionario
		 from auxiliares_d ad
		 inner join temp_productos te using (idproducto)
		 inner join(SELECT distinct idorigenc, periodo, idtipo, idpoliza 
					FROM polizas AS p 
					INNER JOIN polizas_d AS pd USING (idorigenc, periodo, idtipo, idpoliza) 
					WHERE idtipo = 3 AND idcuenta LIKE '10102%' AND periodo:: integer BETWEEN p_inicial and p_final) as pol using (idorigenc, periodo, idtipo, idpoliza)
		 where ad.tipomov = 0 and ad.periodo:: integer between p_inicial and p_final
		 UNION ALL
		 select ad.*, te.idcuestionario
		 from auxiliares_d_h ad
		 inner join temp_productos te using (idproducto)
		 inner join(SELECT distinct idorigenc, periodo, idtipo, idpoliza 
					FROM polizas AS p 
					INNER JOIN polizas_d AS pd USING (idorigenc, periodo, idtipo, idpoliza) 
					WHERE idtipo = 3 AND idcuenta LIKE '10102%' AND periodo:: integer BETWEEN p_inicial and p_final) as pol using (idorigenc, periodo, idtipo, idpoliza)
		 where ad.tipomov = 0 and ad.periodo:: integer between p_inicial and p_final);

	CREATE INDEX index_temp_auxi
	ON temp_auxi (idorigenp,idproducto,idauxiliar);
	raise notice 'Se genero la tabla temp_auxi';

	for r_prod
	in  select   *
		from     tablas
		where    idtabla = 'cuestionario_opera_cnbv2023'
		order by idelemento::integer
	loop

	raise notice 'Cuestionario Operativo CNBV por CLIENTE:  %', r_prod.nombre;

	IF (r_prod.dato2 is not null and TRIM(r_prod.dato2) <> '') THEN

	for r_paso in 
	(select insm, sum(entradas_monto+salidas_monto) monto_entr_sali, sum(entradas_numero+salidas_numero) num_entr_sali,tipo_oper
	 from (select (case when cargoabono=0 THEN monto_operaciones else 0 end) salidas_monto,
				  (case when cargoabono=1 THEN monto_operaciones else 0 end) entradas_monto,
				  (case when cargoabono=0 THEN numero_operaciones else 0 end) salidas_numero,
				  (case when cargoabono=1 THEN numero_operaciones else 0 end) entradas_numero,
				  (case when cargoabono=0 then 2
						when cargoabono=1 then 1 end) tipo_oper,
				   insm 
		   from (select insm,cargoabono,count(*) numero_operaciones,sum(monto_operaciones) monto_operaciones 
				 from (select (case when ad.idtipo=1 and po.concepto like '%***( EFECTIVO )***%' then 1 /*Efectivo*/
									when ad.idtipo=2 then 2	/*Cheques Nominativo o al Portador girado en territorio nacional*/
									when ad.idtipo=1 and po.concepto like '%***( SPEI )***%' then 6 /*Transferencias Electronicas de Fondos*/
									else 6 /*Resto idtipo=3*/ end) as insm,
							   ad.cargoabono,
							   (ad.monto+ad.montoio+ad.montoim+ad.montoiva+ad.montoivaim) as monto_operaciones
					   from temp_auxi ad 
					   inner join polizas po using (idorigenc,periodo,idtipo,idpoliza)
					   where r_prod.idelemento::integer = ad.idcuestionario) ax 
				 group by insm,cargoabono) aux) mont_num 
	 group by insm,tipo_oper
	 order by insm,tipo_oper) 

	loop
/*
	r.periodo 							:= trim(to_char(perio,'9999'));
	r.clave_formulario 					:= 'B';
	r.clave_entidad 					:= clave_ent;
	r.producto_servicio 				:= trim(to_char(r_prod.idelemento::numeric,'99'));
	r.tipo_moneda 						:= '1';
	r.tipo_instrumento_monetario 		:= trim(to_char(r_paso.insm::numeric,'99'));
	r.num_operaciones_entrada 			:= trim(to_char(r_paso.num_entr::numeric,'99999999999999999'));
	r.monto_operaciones_entrada_mn 		:= trim(to_char(r_paso.mon_entra::numeric,'99999999999999999'));
	r.num_operaciones_salida 			:= trim(to_char(r_paso.num_sali::numeric,'99999999999999999'));
	r.monto_operaciones_salida_mn 		:= trim(to_char(r_paso.mont_sal::numeric,'99999999999999999'));*/

	r.anio 							    := trim(to_char(perio,'9999'));
	r.clave_formulario 					:= 'B';
	r.clave_entidad 					:= clave_ent;
	r.producto_servicio 				:= trim(to_char(r_prod.idelemento::numeric,'99'));
	r.tipo_moneda 						:= '1';
	r.tipo_instrumento_monetario 		:= trim(to_char(r_paso.insm::numeric,'99'));
	r.operac_entr_salida                := r_paso.tipo_oper;
	r.numero_operaciones                := trim(to_char(r_paso.num_entr_sali,'99999999999999999'));
	r.monto_operaciones                 := trim(to_char(r_paso.monto_entr_sali,'99999999999999999'));

	return next r;

	insert into copiar values(y,
		coalesce(r.anio 							::text,'')||';'||
		coalesce(r.clave_formulario 				::text,'')||';'||
		coalesce(r.clave_entidad 					::text,'')||';'||
		coalesce(r.producto_servicio 				::text,'')||';'||
		coalesce(r.tipo_moneda 						::text,'')||';'||
		coalesce(r.tipo_instrumento_monetario 		::text,'')||';'||
		coalesce(r.operac_entr_salida    			::text,'')||';'||
		coalesce(r.numero_operaciones           	::text,'')||';'||
		coalesce(r.monto_operaciones    			::text,''));

	end loop;

	select into fecha to_char(CURRENT_DATE,'dd|mm|yyyy');
	execute 'copy (select fila from copiar order by id) to ''/tmp/B_con_encabezados_'||fecha||'.csv''  ';
	execute 'copy (select fila from copiar where id > 0 order by id) to ''/tmp/B_sin_encabezados_'||fecha||'.csv''  ';

	end IF;
	end loop;
	return;
	end;
$$ language 'plpgsql';
